/*
Author: Khoa Bui
Version: 0.1
Description: Exercise 5, Domesticated interface. this file create the Domesticated interface with there method.
*/
public interface Domesticated {
    void walk();

    void greetHuman();
}
