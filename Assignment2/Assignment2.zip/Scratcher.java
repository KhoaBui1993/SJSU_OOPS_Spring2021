/*
Author: Khoa Bui
Version: 0.1
Description: Exercise 5, Scratcher interface. this file create the Scratcher interface with there method.
*/
public interface Scratcher {
    void scratch();
}
