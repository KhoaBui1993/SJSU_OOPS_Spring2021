/*
Author: Khoa Bui
Version: 0.1
Description: Exercise 5, Swimmer interface. this file create the Swimmer interface with there method.
*/
public interface Swimmer {
    void swim();
}
