package Exercise1;
public class StudentTest {
    public static void main(String[] args) throws Exception
    {
        Student student1 = new Student("John", "Smith", 20, (float)3.6, "Computer Science", "School of Computer Science");
        student1.Print_Information();
    }
}
