package Exercise5;

public interface Scratcher {
    void scratch();
}
