package Exercise5;

public interface Domesticated {
    void walk();

    void greetHuman();
}
