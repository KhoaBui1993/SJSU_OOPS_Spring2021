package Exercise5;

public interface Swimmer {
    void swim();
}
